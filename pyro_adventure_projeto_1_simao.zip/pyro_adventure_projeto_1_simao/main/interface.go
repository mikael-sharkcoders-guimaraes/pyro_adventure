components {
  id: "interface"
  component: "/main/interface.gui"
  position {
    x: -4.725093
    y: -3.5708673
  }
}
